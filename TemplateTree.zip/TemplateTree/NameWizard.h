#pragma once

#include <QDialog>
#include "ui_NameWizard.h"

class NameWizard : public QDialog
{
	Q_OBJECT

public:
	NameWizard(QWidget *parent = nullptr);
	~NameWizard();

private:
	void InitUi();
	void InitEvent();

	void SlotFinish();
	void SlotCancel();
public:
	QString _name;

private:
	Ui::NameWizardClass ui;
};
