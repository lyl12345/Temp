#pragma once

#include <QTreeView>
#include <QFileSystemModel>
#include <QMenu>
#include <QDragEnterEvent>

class TemplateTreeView : public QTreeView
{
	Q_OBJECT

public:
	TemplateTreeView(QWidget* parent);
	~TemplateTreeView();

private:
	void InitUi();
	void InitEvent();

	void SlotPopupMenu(const QPoint& pos); 
	void SlotDeleteItem();
	void SlotMakeDir();

protected:
	void dragEnterEvent(QDragEnterEvent* event) override;
	void dragMoveEvent(QDragMoveEvent* event) override;
	void dropEvent(QDropEvent* event) override;

private:
	QFileSystemModel* _model{ nullptr };
	QModelIndex _root_index;
	QMenu* _menu{ nullptr };
	QAction* _delete_item{ nullptr };
	QAction* _create_dir{ nullptr };
};
