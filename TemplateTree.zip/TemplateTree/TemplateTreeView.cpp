#include "TemplateTreeView.h"
#include "NameWizard.h"
#include <QDragEnterEvent>
#include <QMimeData>
#include <QDropEvent>
#include <QDrag>

TemplateTreeView::TemplateTreeView(QWidget* parent)
	: QTreeView(parent)
{
	InitUi();
	InitEvent();
}

TemplateTreeView::~TemplateTreeView()
{}

void TemplateTreeView::InitUi()
{
	this->setDragDropMode(QTreeView::DragDrop);
	this->setSelectionMode(QAbstractItemView::ExtendedSelection);

	_model = new QFileSystemModel(this);
	this->setModel(_model);
	_root_index = _model->setRootPath("C:\\Users\\bigca\\Desktop\\TEST");
	this->setRootIndex(_root_index);
	int c = _model->columnCount();
	for (int i = 1; i < c; i++)
	{
		this->setColumnHidden(i, true);
	}

	_menu = new QMenu(this);
	_create_dir = _menu->addAction(tr("Make Dir"));
	_delete_item = _menu->addAction(tr("Delete"));
	
}

void TemplateTreeView::InitEvent()
{
	this->setContextMenuPolicy(Qt::CustomContextMenu);
	connect(this, &QTreeView::customContextMenuRequested, this, &TemplateTreeView::SlotPopupMenu);
	connect(_delete_item, &QAction::triggered, this, &TemplateTreeView::SlotDeleteItem);
	connect(_create_dir, &QAction::triggered, this, &TemplateTreeView::SlotMakeDir);
}

void TemplateTreeView::SlotPopupMenu(const QPoint& pos)
{
	auto indexes = this->selectedIndexes();
	_create_dir->setEnabled(true);
	if (indexes.size() > 1)
	{
		_create_dir->setEnabled(false);
	}
	else if (indexes.size() == 1)
	{
		bool is_dir = _model->isDir(indexes[0]);
		_create_dir->setEnabled(is_dir);
	}
	_menu->exec(QCursor::pos());
}

void TemplateTreeView::SlotDeleteItem()
{
	auto selected_list = this->selectionModel()->selectedIndexes();
	for (const auto& index : selected_list)
	{
		_model->remove(index);
	}
}

void TemplateTreeView::SlotMakeDir()
{
	NameWizard dlg;
	int c = dlg.exec();
	if (c == QDialog::Accepted)
	{
		QModelIndex idx;
		auto indexes = this->selectedIndexes();
		if (indexes.size()==1)
			_model->mkdir(indexes[0], dlg._name);
		else
			_model->mkdir(_root_index, dlg._name);
	}
}

// ��д��ק�¼���������
void TemplateTreeView::dragEnterEvent(QDragEnterEvent* event)
{
	if (event->mimeData()->hasFormat("application/x-qabstractitemmodeldatalist"))
	{
		event->acceptProposedAction();
	}
}

void TemplateTreeView::dragMoveEvent(QDragMoveEvent* event)
{
	if (event->mimeData()->hasFormat("application/x-qabstractitemmodeldatalist"))
	{
		event->acceptProposedAction();
	}
}

void TemplateTreeView::dropEvent(QDropEvent* event)
{
	//if (event->mimeData()->hasFormat("application/x-qabstractitemmodeldatalist"))
	//{
	//	//QAbstractItemModel* model = model();
	//	const QMimeData* mimeData = event->mimeData();
	//	QDrag* drag = (QDrag*)event->source();
	//	drag->item
	//	// ��ȡҪ�ƶ����ļ�·��
	//	QModelIndex index = _model->indexFromItem(drag->item());
	//	if (!index.isValid())
	//	{
	//		return;
	//	}

	//	// ִ���ƶ�����
	//	_model->moveRows(index.parent(), index.row(), 1, _model->index(index.row() + 1, 0), 1);
	//	event->accept();
	//}
}