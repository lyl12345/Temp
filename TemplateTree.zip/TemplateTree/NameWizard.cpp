#include "NameWizard.h"
#include <QMessageBox>

NameWizard::NameWizard(QWidget *parent)
	: QDialog(parent)
{
	ui.setupUi(this);
	InitUi();
	InitEvent();
}

NameWizard::~NameWizard()
{}

void NameWizard::InitUi()
{
}

void NameWizard::InitEvent()
{
	connect(ui.finish, &QPushButton::clicked, this, &NameWizard::SlotFinish);
	connect(ui.cancel, &QPushButton::clicked, this, &NameWizard::SlotCancel);
}

void NameWizard::SlotFinish()
{
	_name = ui.lineEdit->text();
	if (_name == "")
	{
		//QMessageBox::information(nullptr, "", )
	}
	this->accept();
}

void NameWizard::SlotCancel()
{
	this->reject();
}
